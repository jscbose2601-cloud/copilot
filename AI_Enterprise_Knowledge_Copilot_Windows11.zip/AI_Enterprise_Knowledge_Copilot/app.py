import os
import streamlit as st
from dotenv import load_dotenv

from rag_engine import (
    add_documents, load_knowledge_base, retrieve, answer_question,
    summarize_document, compare_documents, list_documents, clear_knowledge_base
)

load_dotenv()

APP_TITLE = "Enterprise Knowledge Copilot"

st.set_page_config(
    page_title=APP_TITLE,
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ---------- Styling ----------
st.markdown("""
<style>
    .stApp { background: #0b1020; color: #eef2ff; }
    [data-testid="stSidebar"] { background: #111a30; }
    .hero {
        padding: 1.5rem 1.7rem; border-radius: 18px;
        background: linear-gradient(120deg, #18294b, #35245d);
        border: 1px solid #34456b; margin-bottom: 1.2rem;
    }
    .hero h1 { color: #ffffff; margin: 0; font-size: 2rem; }
    .hero p { color: #d6def5; margin: .45rem 0 0 0; }
    .metric-card {
        background: #151f37; border: 1px solid #2b3a5b;
        padding: 1rem; border-radius: 14px;
    }
    .source-card {
        background: #131d33; border-left: 3px solid #8b7cff;
        padding: .75rem 1rem; border-radius: 8px; margin: .4rem 0;
    }
    div[data-testid="stChatMessage"] { border: 1px solid #263653; }
    .small-muted { color: #aab7d4; font-size: .88rem; }
</style>
""", unsafe_allow_html=True)

if "messages" not in st.session_state:
    st.session_state.messages = []

# ---------- Sidebar ----------
with st.sidebar:
    st.markdown("## 🧠 Knowledge Copilot")
    st.caption("Your private, local document assistant")
    st.divider()

    st.markdown("### 📚 Knowledge base")
    uploaded_files = st.file_uploader(
        "Upload company documents",
        type=["pdf", "docx", "txt"],
        accept_multiple_files=True,
        help="Supported formats: PDF, Word DOCX and TXT."
    )

    if st.button("⚡ Process uploaded documents", use_container_width=True):
        if not uploaded_files:
            st.warning("Please upload at least one document.")
        else:
            with st.spinner("Reading, chunking and indexing documents..."):
                try:
                    result = add_documents(uploaded_files)
                    st.success(result)
                except Exception as exc:
                    st.error(f"Could not process documents: {exc}")

    if st.button("↻ Refresh knowledge base", use_container_width=True):
        load_knowledge_base()
        st.rerun()

    st.divider()
    docs = list_documents()
    st.metric("Indexed documents", len(docs))
    st.metric("Knowledge chunks", sum(d["chunks"] for d in docs))

    with st.expander("View indexed documents"):
        if docs:
            for doc in docs:
                st.write(f"📄 **{doc['name']}**")
                st.caption(f"{doc['chunks']} chunks")
        else:
            st.caption("No documents indexed yet.")

    if st.button("🗑️ Clear all indexed documents", use_container_width=True):
        clear_knowledge_base()
        st.session_state.messages = []
        st.success("Knowledge base cleared.")
        st.rerun()

    st.divider()
    st.caption("Runs locally with Ollama. Your documents are stored on this computer.")

# ---------- Header ----------
st.markdown("""
<div class="hero">
  <h1>🧠 Enterprise Knowledge Intelligence</h1>
  <p>Turn company documents into trusted answers, summaries and decisions.</p>
</div>
""", unsafe_allow_html=True)

docs = list_documents()
col1, col2, col3 = st.columns(3)
with col1:
    st.markdown('<div class="metric-card">📁 <b>Documents</b><h2>' + str(len(docs)) + '</h2></div>', unsafe_allow_html=True)
with col2:
    st.markdown('<div class="metric-card">🧩 <b>Knowledge chunks</b><h2>' + str(sum(d["chunks"] for d in docs)) + '</h2></div>', unsafe_allow_html=True)
with col3:
    st.markdown('<div class="metric-card">🔒 <b>AI processing</b><h2>Local</h2></div>', unsafe_allow_html=True)

tab_chat, tab_summary, tab_compare, tab_guide = st.tabs(
    ["💬 Ask Copilot", "📝 Summarize", "⚖️ Compare documents", "🚀 How to use"]
)

# ---------- Chat ----------
with tab_chat:
    st.subheader("Ask questions about your company documents")
    st.caption("Answers are grounded in retrieved document passages and include source references.")

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            if msg.get("sources"):
                with st.expander("📚 View sources"):
                    for src in msg["sources"]:
                        st.markdown(
                            f"<div class='source-card'><b>{src['source']}</b> · Page {src['page']}<br>{src['preview']}</div>",
                            unsafe_allow_html=True
                        )

    question = st.chat_input("Example: What is the annual leave policy?")
    if question:
        st.session_state.messages.append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)

        with st.chat_message("assistant"):
            if not docs:
                st.warning("Upload and process documents first using the left sidebar.")
            else:
                with st.spinner("Searching documents and generating an answer..."):
                    try:
                        retrieved = retrieve(question, top_k=4)
                        recent_history = st.session_state.messages[-7:-1]
                        answer = answer_question(question, retrieved, recent_history)
                        st.markdown(answer)
                        sources = [
                            {
                                "source": item["source"],
                                "page": item["page"],
                                "preview": item["text"][:240].replace("\n", " ")
                            }
                            for item in retrieved
                        ]
                        with st.expander("📚 View sources"):
                            for src in sources:
                                st.markdown(
                                    f"<div class='source-card'><b>{src['source']}</b> · Page {src['page']}<br>{src['preview']}</div>",
                                    unsafe_allow_html=True
                                )
                        st.session_state.messages.append({
                            "role": "assistant", "content": answer, "sources": sources
                        })
                    except Exception as exc:
                        st.error(f"AI request failed: {exc}")
                        st.info("Check that Ollama is running and the model is downloaded.")

    if st.button("Clear conversation"):
        st.session_state.messages = []
        st.rerun()

# ---------- Summarize ----------
with tab_summary:
    st.subheader("Document summarizer")
    if not docs:
        st.info("Upload and process documents to use summarization.")
    else:
        doc_names = [d["name"] for d in docs]
        selected = st.selectbox("Choose a document", doc_names)
        if st.button("Generate summary", key="summarize_btn"):
            with st.spinner("Creating summary with the local model..."):
                try:
                    summary = summarize_document(selected)
                    st.markdown(summary)
                except Exception as exc:
                    st.error(str(exc))

# ---------- Compare ----------
with tab_compare:
    st.subheader("Compare information across documents")
    if len(docs) < 2:
        st.info("Index at least two documents to compare them.")
    else:
        doc_names = [d["name"] for d in docs]
        left, right = st.columns(2)
        with left:
            doc_a = st.selectbox("First document", doc_names, key="doc_a")
        with right:
            doc_b = st.selectbox(
                "Second document",
                [name for name in doc_names if name != doc_a],
                key="doc_b"
            )
        comparison_question = st.text_input(
            "What should be compared?",
            placeholder="Compare leave rules, eligibility and approval process"
        )
        if st.button("Compare documents", key="compare_btn"):
            if not comparison_question.strip():
                st.warning("Enter what you want to compare.")
            else:
                with st.spinner("Comparing selected documents..."):
                    try:
                        result = compare_documents(doc_a, doc_b, comparison_question)
                        st.markdown(result)
                    except Exception as exc:
                        st.error(str(exc))

# ---------- Guide ----------
with tab_guide:
    st.subheader("Quick start")
    st.markdown("""
1. Install Python and Ollama on Windows.
2. Download the local model using `ollama pull llama3.2:1b`.
3. Run `pip install -r requirements.txt` in this project folder.
4. Start Ollama (the Windows Ollama app normally runs in the background).
5. Run `streamlit run app.py`.
6. Upload PDF, DOCX or TXT company documents in the sidebar.
7. Click **Process uploaded documents**, then ask questions.

**Demo questions**
- What is the annual leave policy?
- Who approves employee leave?
- Summarize the uploaded policy.
- Compare the leave policy in two documents.

**Important:** This is a hackathon prototype. Verify important HR, legal, financial or operational decisions against the original documents. Do not upload confidential company documents without permission.
""")
