# AI Enterprise Knowledge Intelligence & Decision Copilot

A beginner-friendly local RAG application built with Python, Streamlit, Ollama and sentence-transformers.

## Features

- Upload PDF, DOCX and TXT files
- Extract and split document text into chunks
- Create local sentence embeddings
- Search relevant passages using cosine similarity
- Generate answers with a local Ollama model
- Show source document and page references
- Keep recent conversation context for follow-up questions
- Summarize a selected document
- Compare two indexed documents
- Persist the knowledge base locally between app restarts

## Recommended setup

- Windows 11
- 8 GB RAM
- Python 3.10 or 3.11
- Ollama
- `llama3.2:1b` local model

## 1. Install Python

Install Python 3.10 or 3.11 from https://www.python.org/downloads/

During installation, enable **Add Python to PATH**.

## 2. Install Ollama

Download from https://ollama.com/download

Open PowerShell and run:

```powershell
ollama pull llama3.2:1b
```

The Ollama Windows app normally runs its local service in the background. Check it with:

```powershell
ollama list
```

## 3. Open the project

Extract the ZIP file. Open the `AI_Enterprise_Knowledge_Copilot` folder in VS Code.

Open the VS Code terminal in that folder.

## 4. Create a virtual environment

```powershell
python -m venv .venv
.venv\Scripts\activate
```

If PowerShell blocks activation, use Command Prompt terminal or run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.venv\Scripts\Activate.ps1
```

## 5. Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

The first run downloads the embedding model from Hugging Face. Internet is needed for this initial download.

## 6. Configure environment

Copy `.env.example` to `.env`.

PowerShell:

```powershell
Copy-Item .env.example .env
```

No API key is needed.

## 7. Run the app

```powershell
streamlit run app.py
```

Open the local address shown in the terminal, usually http://localhost:8501

## 8. Test

1. Upload two sample policy PDFs, or one PDF and one DOCX.
2. Click **Process uploaded documents**.
3. Ask: "What is the leave policy?"
4. Ask a follow-up: "Who approves it?"
5. Open **Summarize** and summarize one document.
6. Open **Compare documents** and compare two documents.

## Project structure

```text
AI_Enterprise_Knowledge_Copilot/
├── app.py
├── rag_engine.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── data/
└── vectorstore/
    ├── chunks.json
    └── embeddings.npy
```

## How RAG works here

1. **Load:** Read PDF, DOCX or TXT documents.
2. **Chunk:** Split document text into smaller overlapping passages.
3. **Embed:** Convert each passage into a numerical vector.
4. **Store:** Save passage text and vectors locally.
5. **Retrieve:** Embed the user's question and rank passages by cosine similarity.
6. **Generate:** Send the question and retrieved passages to Ollama.
7. **Cite:** Display source filenames and page references.

## Troubleshooting

### `ollama` connection error

Open the Ollama Windows app. In PowerShell, check:

```powershell
ollama list
```

If needed, run `ollama serve` in a separate terminal.

### Model not found

```powershell
ollama pull llama3.2:1b
```

### Slow response

Close unnecessary applications. Keep the 1B model. Processing documents and the first embedding-model download can take time.

### PDF has no extracted text

Some PDFs are scanned images. This starter version extracts selectable PDF text; OCR for scanned PDFs is a future enhancement.

### Windows package installation errors

Use Python 3.10 or 3.11 in a fresh virtual environment, then retry `pip install -r requirements.txt`.

## Important limitations

This is a hackathon prototype, not a production enterprise security system. Do not upload confidential documents without authorization. Validate important decisions against original documents. Retrieval-based summaries and comparisons may not include every page because the prototype selects the most relevant chunks.
